**This python package is made as an exercise purpose on 42 Angouleme Campus by the student sylabbe**





https://packaging.python.org/en/latest/tutorials/packaging-projects/